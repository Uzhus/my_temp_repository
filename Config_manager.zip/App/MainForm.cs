﻿using MaterialSkin.Controls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace App
{
    public partial class MainForm : MaterialForm
    {

        private List<string> posts = new List<string>();

        private List<string> configuries = new List<string>();


        public MainForm()
        {
            InitializeComponent();
            initPostsList();
            initConfiguriesList();
            refreshPostComboBox();
            reviewButton.Enabled = false;
        }

        private void initPostsList()
        {
            posts.Add("Бухгалтер");
            posts.Add("Диспетчер");
            posts.Add("Инженер по планированию");
            posts.Add("Инспектор по кадрам");
            posts.Add("Кладовщик");
            posts.Add("Маркшейдер");
            posts.Add("Охранник");
            posts.Add("Секретарь");
            posts.Add("Специалист по охране труда");
            posts.Add("Экономист");
        }

        private void initConfiguriesList()
        {
            configuries.Add("a)\tБлок системный стандартный;\r\nb)\tМонитор 24”;\r\nc)\tМФУ А4 лазерное монохромное.\r\n");
            configuries.Add("a)\tБлок системный производительный;\r\nb)\tМонитор 24”;\r\nc)\tПринтер А4 лазерный монохромный.\r\n");
            configuries.Add("a)\tБлок системный производительный;\r\nb)\tМонитор 27”;\r\nc)\tПринтер А3 лазерный цветной.\r\n");
            configuries.Add("a)\tБлок системный стандартный;\r\nb)\tМонитор 24”;\r\nc)\tМФУ А4 лазерное монохромное.\r\n");
            configuries.Add("a)\tБлок системный стандартный;\r\nb)\tМонитор 24”;\r\nc)\tМФУ А4 лазерное монохромное.\r\n");
            configuries.Add("a)\tграфическая станция;\r\nb)\tМонитор 27” 2шт.;\r\nc)\tПлоттер А0.\r\n");
            configuries.Add("a)\tВидеосервер;\r\nb)\tМонитор 24” 4шт.\r\n");
            configuries.Add("a)\tБлок системный стандартный;\r\nb)\tМонитор 24”;\r\nc)\tМФУ А4 лазерное цветное.\r\n");
            configuries.Add("a)\tБлок системный производительный;\r\nb)\tМонитор 24”;\r\nc)\tПринтер А3 лазерный цветной.\r\n");
            configuries.Add("a)\tБлок системный производительный;\r\nb)\tМонитор 24” 2шт.;\r\nc)\tМФУ А4 лазерное монохромное.\r\n");
        }

        private void refreshPostComboBox()
        {
            postComboBox.Items.Clear();
            foreach (var item in posts)
            {
                postComboBox.Items.Add(item);
            }
        }

        private string configure()
        {
            int count = 0;
            foreach(var post in posts)
            {
                if (post.Equals(postComboBox.Text))
                {
                    reviewButton.Enabled = true;
                    return configuries[count];
                }
                count += 1;
            }
            return "Выберите должность из списка.";
        }
        
        private void startButton_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = configure();
            
        }

        private void reviewButton_Click(object sender, EventArgs e)
        {
            MessageForm messageForm = new MessageForm();
            messageForm.ShowDialog();
            reviewButton.Enabled = false;
        }
    }
}
