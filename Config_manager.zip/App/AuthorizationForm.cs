﻿using MaterialSkin.Controls;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace App
{
    public partial class AuthorizationForm : MaterialForm
    {
        public AuthorizationForm()
        {
            InitializeComponent();
        }

        private void startButton_Click(object sender, EventArgs e)
        {
            string answerText = Interaction.InputBox("Введите имя", "Ввод данных");
            if (answerText.Length != 0)
            {
                string answerText2 = Interaction.InputBox("Введите фамилию", "Ввод данных");
                if (answerText2.Length != 0)
                {
                    MainForm mainForm = new MainForm();
                    mainForm.Show();
                    this.Hide();
                }
                    
            }
        }
    }
}
